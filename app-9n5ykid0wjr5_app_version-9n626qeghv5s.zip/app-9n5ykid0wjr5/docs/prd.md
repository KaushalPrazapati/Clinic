# Ayushman Clinic Website Requirements Document

## 1. Application Overview

### 1.1 Application Name
Ayushman Clinic Official Website

### 1.2 Application Description
A modern, mobile-first medical clinic website designed to build trust, increase patient engagement, and facilitate easy appointment booking for Ayushman Clinic in Patna. The website serves as the digital presence for a trusted local healthcare provider, focusing on clear communication of services, professional presentation, and seamless patient contact options.

## 2. Core Features

### 2.1 Hero Section
- Display headline: Trusted Healthcare for Your Family in Patna
- Display subheading: OPD • Diagnostics • Medical Store — Under One Roof
- Two primary call-to-action buttons: Call Now and WhatsApp Appointment
- Clean doctor/clinic-themed imagery with soft entrance animation

### 2.2 Trust Highlights Section
Display four key trust indicators with icons:
- 4.6★ Google Rating (30+ Reviews)
- Experienced Doctor
- In-house Diagnostics
- Clean & Hygienic Clinic

### 2.3 About Section
- Professional introduction to the doctor/clinic
- Patient-first care emphasis
- Space for doctor photo
- Short, respectful content without medical jargon

### 2.4 Services Section
Modern card layout displaying four services:
- OPD Consultation
- Diagnostic Tests
- Diabetes & Blood Pressure Care
- Medical Store

Each card includes:
- Service icon
- Service name
- One-line patient-friendly description

### 2.5 Patient Reviews Section
- Slider or carousel layout for testimonials
- Display star ratings
- Real-style patient testimonials
- Trust-building presentation

### 2.6 Appointment Section
Simple appointment form with fields:
- Name
- Phone number
- Preferred time

On form submission, redirect to WhatsApp with pre-filled appointment message.

### 2.7 Location & Contact Section
- Embedded Google Map
- Full clinic address: Akashwani Road, Bailey Road, Khajpura, Patna, Bihar – 800014
- Clinic operating hours
- Click-to-call phone number: 094700 75755

### 2.8 Footer
- Clinic name
- Contact information
- WhatsApp button
- Minimal, professional design

### 2.9 Mobile Features
- Sticky bottom bar on mobile with Call and WhatsApp buttons
- Fully responsive, mobile-first layout

## 3. Design Requirements

### 3.1 Visual Style
- Clean, professional, medical-grade design
- White background with medical green/blue accents
- Calm, trustworthy aesthetic
- No flashy or gimmicky visuals
- Subtle animations: fade-in, slide-up effects

### 3.2 Typography & Accessibility
- Large readable fonts
- High contrast for readability
- Accessible for all age groups
- Clear visual hierarchy

### 3.3 Responsive Design
- Mobile-first approach
- Fully responsive across all devices
- Optimized touch targets for mobile users

## 4. Technical Requirements

### 4.1 Performance
- Fast loading times
- Optimized images and assets

### 4.2 SEO & Discoverability
- SEO-friendly structure
- Optimized for local search
- Proper meta tags and descriptions

### 4.3 User Experience
- Clear conversion flow toward calling or WhatsApp
- Intuitive navigation
- Seamless appointment booking process

## 5. Content Tone
- Professional and calm
- Trustworthy and patient-centric
- Clear communication without medical jargon overload
- Focus on clarity, dignity, and reliability