# Task: Build Ayushman Clinic Website

## Plan
- [x] Setup Theme and Assets
  - [x] Configure tailwind.config.js with 'Natural' theme and Gilda Display font
  - [x] Update index.css with CSS variables and font imports
  - [x] Search for high-quality medical images using image_search
- [x] Create Layout Components
  - [x] Implement Navbar with desktop/mobile navigation
  - [x] Implement Footer with contact info
  - [x] Implement MobileStickyBar for quick access to Call/WhatsApp
- [x] Build Home Page Sections
  - [x] Implement Hero Section with trust-building visuals and CTAs
  - [x] Implement Trust Highlights Section with icons
  - [x] Implement About Section with doctor/clinic info
  - [x] Implement Services Section with card layout
  - [x] Implement Patient Reviews carousel
  - [x] Implement Appointment Section with WhatsApp redirect logic
  - [x] Implement Location & Contact Section with Google Maps embed
- [x] Final Polish
  - [x] Add scroll animations (fade-in, float-up)
  - [x] Verify mobile responsiveness and touch targets
  - [x] Run lint and fix any issues

