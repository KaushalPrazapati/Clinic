import { Phone, Mail, MapPin, Clock, MessageSquare } from "lucide-react";
import { Link } from "react-router-dom";

export function Footer() {
  return (
    <footer className="bg-secondary/50 pt-16 pb-24 md:pb-8 border-t border-border">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-xl">A</span>
              </div>
              <div className="flex flex-col">
                <span className="font-gilda-display text-xl leading-tight font-bold tracking-tight text-primary">
                  Ayushman Clinic
                </span>
                <span className="text-[10px] uppercase tracking-[0.2em] font-medium text-muted-foreground">
                  Patna's Trusted Healthcare
                </span>
              </div>
            </Link>
            <p className="text-muted-foreground text-sm max-w-sm mb-6 leading-relaxed">
              Providing comprehensive healthcare services including OPD consultations, 
              diagnostics, and pharmacy services under one roof. Your health is our priority.
            </p>
            <div className="flex gap-4">
              <a href="https://wa.me/919470075755" className="w-10 h-10 rounded-full bg-accent flex items-center justify-center hover:bg-primary hover:text-white transition-all duration-300">
                <MessageSquare className="w-5 h-5" />
              </a>
              <a href="tel:09470075755" className="w-10 h-10 rounded-full bg-accent flex items-center justify-center hover:bg-primary hover:text-white transition-all duration-300">
                <Phone className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-gilda-display text-lg font-bold mb-6 text-foreground">Quick Links</h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#services" className="text-muted-foreground hover:text-primary transition-colors">Our Services</a></li>
              <li><a href="#about" className="text-muted-foreground hover:text-primary transition-colors">About Doctor</a></li>
              <li><a href="#reviews" className="text-muted-foreground hover:text-primary transition-colors">Patient Reviews</a></li>
              <li><a href="#appointment" className="text-muted-foreground hover:text-primary transition-colors">Book Appointment</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-gilda-display text-lg font-bold mb-6 text-foreground">Contact Info</h4>
            <ul className="space-y-4 text-sm">
              <li className="flex gap-3">
                <MapPin className="w-5 h-5 text-primary shrink-0" />
                <span className="text-muted-foreground">Akashwani Road, Bailey Road, Khajpura, Patna, Bihar – 800014</span>
              </li>
              <li className="flex gap-3 text-muted-foreground">
                <Phone className="w-5 h-5 text-primary shrink-0" />
                <a href="tel:09470075755" className="hover:text-primary">094700 75755</a>
              </li>
              <li className="flex gap-3 text-muted-foreground">
                <Clock className="w-5 h-5 text-primary shrink-0" />
                <span>Mon - Sat: 10:00 AM - 8:00 PM</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p>© 2026 Ayushman Clinic Official Website. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-primary">Privacy Policy</a>
            <a href="#" className="hover:text-primary">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
