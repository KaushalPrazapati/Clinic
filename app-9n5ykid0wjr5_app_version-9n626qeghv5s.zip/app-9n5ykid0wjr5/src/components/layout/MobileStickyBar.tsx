import { Phone, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";

export function MobileStickyBar() {
  return (
    <div className="md:hidden fixed bottom-4 left-4 right-4 z-[40] pointer-events-none">
      <div className="flex gap-4 pointer-events-auto">
        <Button 
          variant="outline"
          className="flex-1 rounded-2xl h-14 bg-white text-primary border-primary border-2 font-bold shadow-lg hover:bg-accent transition-all active:scale-95 border-solid"
          onClick={() => window.location.href = "tel:09470075755"}
        >
          <Phone className="mr-2 h-5 w-5" />
          Call Now
        </Button>
        <Button 
          className="flex-1 rounded-2xl h-14 bg-primary text-primary-foreground font-bold shadow-lg hover:brightness-110 transition-all active:scale-95"
          onClick={() => window.open("https://wa.me/919470075755", "_blank")}
        >
          <MessageSquare className="mr-2 h-5 w-5" />
          WhatsApp
        </Button>
      </div>
    </div>
  );
}
