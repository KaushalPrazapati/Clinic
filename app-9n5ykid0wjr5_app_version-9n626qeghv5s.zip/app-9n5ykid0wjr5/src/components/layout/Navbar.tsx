import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Menu, X, Phone, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

const navLinks = [
  { name: "Services", href: "#services" },
  { name: "About", href: "#about" },
  { name: "Reviews", href: "#reviews" },
  { name: "Contact", href: "#contact" },
];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4",
        isScrolled
          ? "bg-background/80 backdrop-blur-md shadow-sm py-3"
          : "bg-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-xl">A</span>
          </div>
          <div className="flex flex-col">
            <span className="font-gilda-display text-xl leading-tight font-bold tracking-tight text-primary">
              Ayushman
            </span>
            <span className="text-[10px] uppercase tracking-[0.2em] font-medium text-muted-foreground">
              Clinic Patna
            </span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.name}
              onClick={() => handleNavClick(link.href)}
              className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors"
            >
              {link.name}
            </button>
          ))}
          <Button
            className="rounded-full px-6"
            onClick={() => handleNavClick("#appointment")}
          >
            Book Appointment
          </Button>
        </div>

        {/* Mobile Nav */}
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-background">
              <div className="flex flex-col gap-6 mt-12">
                {navLinks.map((link) => (
                  <button
                    key={link.name}
                    onClick={() => handleNavClick(link.href)}
                    className="text-lg font-gilda-display text-left px-4 py-2 hover:bg-accent rounded-lg transition-colors"
                  >
                    {link.name}
                  </button>
                ))}
                <Button
                  className="rounded-full mt-4"
                  onClick={() => handleNavClick("#appointment")}
                >
                  Book Appointment
                </Button>
                <div className="flex flex-col gap-4 mt-8 pt-8 border-t">
                  <a
                    href="tel:09470075755"
                    className="flex items-center gap-3 text-sm font-medium text-muted-foreground"
                  >
                    <Phone className="h-4 w-4 text-primary" />
                    094700 75755
                  </a>
                  <a
                    href="https://wa.me/919470075755"
                    className="flex items-center gap-3 text-sm font-medium text-muted-foreground"
                  >
                    <MessageSquare className="h-4 w-4 text-primary" />
                    WhatsApp Us
                  </a>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
