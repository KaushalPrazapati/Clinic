import { Stethoscope, Microscope, Activity, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    title: "OPD Consultation",
    desc: "Expert medical advice and treatment for general health issues and specialized concerns.",
    icon: Stethoscope,
    image: "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_c73a0f7e-871a-478c-9d2b-42ab61754df5.jpg",
  },
  {
    title: "Diagnostic Tests",
    desc: "Comprehensive lab tests and screenings with accurate results to aid in effective diagnosis.",
    icon: Microscope,
    image: "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_a5bccc14-33c5-4a2f-aa02-7f47a987c1dc.jpg",
  },
  {
    title: "Diabetes & BP Care",
    desc: "Specialized monitoring and management plans for chronic conditions like hypertension and diabetes.",
    icon: Activity,
    image: "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_df263d8d-99ec-430b-a295-e13216251b8b.jpg",
  },
  {
    title: "Medical Store",
    desc: "In-house pharmacy stocked with genuine medicines and healthcare essentials for your convenience.",
    icon: ShoppingBag,
    image: "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_bd1e4cc1-d4ba-41ec-a9ba-0d0e63812ddf.jpg",
  },
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-background relative">
      <div className="container px-6 mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-gilda-display text-4xl md:text-5xl font-bold text-foreground mb-6">
            Comprehensive <span className="text-primary italic">Medical</span> Services
          </h2>
          <p className="text-lg text-muted-foreground">
            We provide a wide range of healthcare services under one roof, ensuring you get the care you need without multiple trips.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="group bg-secondary/30 rounded-[2rem] overflow-hidden border border-border/50 hover:border-primary/30 transition-all duration-500 hover:shadow-xl hover:shadow-primary/5 hover:-translate-y-2"
            >
              <div className="h-48 overflow-hidden relative">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute top-4 left-4">
                  <div className="w-12 h-12 bg-white/90 backdrop-blur-sm rounded-xl flex items-center justify-center text-primary shadow-sm">
                    <service.icon className="w-6 h-6" />
                  </div>
                </div>
              </div>
              <div className="p-8">
                <h3 className="font-gilda-display text-2xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                  {service.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-6">
                  {service.desc}
                </p>
                <Button 
                  variant="ghost" 
                  className="p-0 h-auto font-bold text-primary hover:text-primary/80 group-hover:gap-2 transition-all"
                  onClick={() => document.querySelector("#appointment")?.scrollIntoView({ behavior: "smooth" })}
                >
                  Learn More <ArrowRight className="w-4 h-4 ml-1 opacity-0 group-hover:opacity-100 transition-all" />
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-20 text-center">
          <div className="inline-block p-1 rounded-full bg-secondary border border-border">
            <div className="flex items-center gap-4 px-6 py-2">
              <span className="text-sm font-medium text-muted-foreground italic">Need a customized health checkup?</span>
              <Button 
                variant="link" 
                className="text-primary font-bold p-0"
                onClick={() => window.open("https://wa.me/919470075755?text=Hello, I have a question about your services.", "_blank")}
              >
                Inquire on WhatsApp
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Background shape */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-primary/5 rounded-full blur-[100px] z-0" />
    </section>
  );
}

function ArrowRight(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 12h14" />
      <path d="m12 5 7 7-7 7" />
    </svg>
  );
}
