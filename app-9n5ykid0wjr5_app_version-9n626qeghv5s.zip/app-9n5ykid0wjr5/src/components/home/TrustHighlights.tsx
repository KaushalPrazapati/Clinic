import { Star, ShieldCheck, Microscope, Sparkles } from "lucide-react";

const highlights = [
  {
    icon: Star,
    title: "4.6★ Google Rating",
    desc: "Highly trusted by patients (30+ reviews)",
    color: "bg-yellow-500/10 text-yellow-600",
  },
  {
    icon: ShieldCheck,
    title: "Experienced Doctor",
    desc: "Professional care for all age groups",
    color: "bg-primary/10 text-primary",
  },
  {
    icon: Microscope,
    title: "In-house Diagnostics",
    desc: "Quick & accurate lab results",
    color: "bg-blue-500/10 text-blue-600",
  },
  {
    icon: Sparkles,
    title: "Clean & Hygienic",
    desc: "Safe and sanitized clinic environment",
    color: "bg-green-500/10 text-green-600",
  },
];

export function TrustHighlights() {
  return (
    <section className="py-12 bg-secondary/30">
      <div className="container px-6 mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {highlights.map((item, index) => (
            <div 
              key={index} 
              className="flex flex-col items-center text-center p-6 bg-background rounded-2xl shadow-sm border border-border/50 transition-all hover:translate-y-[-4px] hover:shadow-md"
            >
              <div className={`w-12 h-12 rounded-xl ${item.color} flex items-center justify-center mb-4`}>
                <item.icon className="w-6 h-6" />
              </div>
              <h3 className="font-gilda-display text-lg font-bold text-foreground mb-1 leading-tight">
                {item.title}
              </h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
