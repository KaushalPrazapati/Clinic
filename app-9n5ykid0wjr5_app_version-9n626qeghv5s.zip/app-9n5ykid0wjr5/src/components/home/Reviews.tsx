import { Star, Quote } from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Card, CardContent } from "@/components/ui/card";

const testimonials = [
  {
    name: "Rajesh Kumar",
    role: "Local Resident",
    text: "Excellent service and professional behavior. The clinic is very clean and the doctor is highly experienced. Got my BP checkup done quickly.",
    rating: 5,
  },
  {
    name: "Suman Singh",
    role: "Patient",
    text: "Very reliable diagnostic services. I always come here for my regular blood tests. The reports are delivered on time and are accurate.",
    rating: 5,
  },
  {
    name: "Amit Verma",
    role: "Parent",
    text: "Friendly staff and calm atmosphere. It's the best clinic in the Bailey Road area for families. Highly recommended for OPD consultations.",
    rating: 4,
  },
  {
    name: "Priyanka Devi",
    role: "Regular Visitor",
    text: "The medical store inside is very convenient. I don't have to go anywhere else to buy prescribed medicines. Great patient care!",
    rating: 5,
  },
];

export function Reviews() {
  return (
    <section id="reviews" className="py-24 bg-secondary/50 relative overflow-hidden">
      <div className="container px-6 mx-auto relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-2xl">
            <h2 className="font-gilda-display text-4xl md:text-5xl font-bold text-foreground mb-6">
              What Our <span className="text-primary italic">Patients</span> Say
            </h2>
            <p className="text-lg text-muted-foreground">
              Real testimonials from the people we serve. Your health and satisfaction are our greatest rewards.
            </p>
          </div>
          <div className="flex items-center gap-4 bg-background px-6 py-4 rounded-2xl shadow-sm border border-border">
            <div className="flex text-yellow-500">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className="w-5 h-5 fill-current" />
              ))}
            </div>
            <div className="font-bold text-foreground">4.6 / 5</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Google Rating</div>
          </div>
        </div>

        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full"
        >
          <CarouselContent className="-ml-4">
            {testimonials.map((testimonial, index) => (
              <CarouselItem key={index} className="pl-4 md:basis-1/2 lg:basis-1/3">
                <Card className="border-none shadow-none bg-background rounded-[2rem] h-full transition-all duration-300 hover:shadow-xl hover:shadow-primary/5">
                  <CardContent className="p-10 flex flex-col h-full">
                    <div className="flex text-yellow-500 mb-6">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                    <Quote className="w-10 h-10 text-primary/10 mb-6" />
                    <p className="text-foreground/80 italic leading-relaxed mb-8 flex-grow">
                      "{testimonial.text}"
                    </p>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center font-bold text-primary font-gilda-display text-xl">
                        {testimonial.name[0]}
                      </div>
                      <div>
                        <div className="font-bold text-foreground">{testimonial.name}</div>
                        <div className="text-xs text-muted-foreground">{testimonial.role}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CarouselItem>
            ))}
          </CarouselContent>
          <div className="flex justify-center gap-4 mt-12 md:hidden">
            <CarouselPrevious className="static translate-y-0" />
            <CarouselNext className="static translate-y-0" />
          </div>
          <div className="hidden md:block">
            <CarouselPrevious className="-left-12 bg-background hover:bg-primary hover:text-white" />
            <CarouselNext className="-right-12 bg-background hover:bg-primary hover:text-white" />
          </div>
        </Carousel>
      </div>
      
      {/* Decorative gradient */}
      <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_at_70%_20%,rgba(var(--primary),0.05)_0%,transparent_50%)] pointer-events-none" />
    </section>
  );
}
