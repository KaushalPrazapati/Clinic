import { CheckCircle2 } from "lucide-react";

export function About() {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="container px-6 mx-auto">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2 relative">
            <div className="relative z-10 rounded-[2rem] overflow-hidden shadow-2xl">
              <img 
                src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_c73a0f7e-871a-478c-9d2b-42ab61754df5.jpg" 
                alt="Ayushman Clinic Doctor" 
                className="w-full h-auto object-cover scale-105 hover:scale-100 transition-transform duration-700"
              />
            </div>
            {/* Decorative shapes */}
            <div className="absolute -top-6 -left-6 w-32 h-32 bg-primary/10 rounded-full z-0 blur-2xl" />
            <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-accent/50 rounded-full z-0 blur-3xl" />
            
            <div className="absolute bottom-8 -right-4 z-20 bg-background p-6 rounded-2xl shadow-xl border border-border hidden md:block animate-float-up">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-foreground">Registered Clinic</div>
                  <div className="text-xs text-muted-foreground">Certified Healthcare Provider</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:w-1/2">
            <h2 className="font-gilda-display text-4xl md:text-5xl font-bold text-foreground mb-6 leading-tight">
              Compassionate Care, <span className="text-primary italic">Professional</span> Excellence
            </h2>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              At Ayushman Clinic, we believe that healthcare is more than just treating symptoms—it's about caring for people. Founded on the principles of trust and accessibility, we provide quality medical services to the Patna community.
            </p>
            <p className="text-lg text-muted-foreground mb-10 leading-relaxed">
              Our clinic combines modern diagnostic tools with a patient-first approach. Whether you're coming in for a routine checkup or specialized care, our team is dedicated to your well-being.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
              {[
                "Experienced Medical Professionals",
                "Patient-Centric Care",
                "Modern Diagnostic Lab",
                "Affordable Consultations",
                "Full-Service Pharmacy",
                "Clean & Sanatized Facility"
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center">
                    <CheckCircle2 className="w-3 h-3 text-primary" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{item}</span>
                </div>
              ))}
            </div>
            
            <div className="p-6 bg-secondary rounded-2xl border border-border/50">
              <p className="italic text-muted-foreground mb-4">
                "Our mission is to provide the highest standard of healthcare that is accessible to every family in Patna. We value the trust our patients place in us."
              </p>
              <div className="font-bold text-foreground">Ayushman Clinic Team</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
