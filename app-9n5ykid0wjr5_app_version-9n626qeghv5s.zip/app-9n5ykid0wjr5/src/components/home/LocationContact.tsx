import { MapPin, Phone, Clock, Mail } from "lucide-react";

export function LocationContact() {
  const address = "Akashwani Road, Bailey Road, Khajpura, Patna, Bihar – 800014";
  const mapQuery = encodeURIComponent("Ayushman Clinic, Akashwani Road, Bailey Road, Khajpura, Patna, Bihar 800014");
  const mapSrc = `https://www.google.com/maps/embed/v1/place?key=AIzaSyB_LJOYJL-84SMuxNB7LtRGhxEQLjswvy0&q=${mapQuery}&language=en&region=cn`;

  return (
    <section id="contact" className="py-24 bg-background">
      <div className="container px-6 mx-auto">
        <div className="flex flex-col lg:flex-row gap-12">
          <div className="lg:w-1/3">
            <h2 className="font-gilda-display text-4xl font-bold text-foreground mb-8">
              Find <span className="text-primary italic">Us</span>
            </h2>
            <p className="text-muted-foreground mb-12">
              We are conveniently located in Patna, making it easy for you to access quality healthcare.
            </p>
            
            <div className="space-y-8">
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <div className="font-bold text-foreground mb-1 text-lg">Our Address</div>
                  <address className="not-italic text-muted-foreground leading-relaxed">
                    {address}
                  </address>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Phone className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <div className="font-bold text-foreground mb-1 text-lg">Call Us</div>
                  <a href="tel:09470075755" className="text-muted-foreground hover:text-primary transition-colors text-lg">
                    094700 75755
                  </a>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <div className="font-bold text-foreground mb-1 text-lg">Working Hours</div>
                  <div className="text-muted-foreground">
                    Mon - Sat: 10:00 AM - 8:00 PM<br />
                    Sunday: Closed
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:w-2/3">
            <div className="h-[450px] rounded-[2rem] overflow-hidden shadow-2xl border-8 border-secondary shadow-primary/5">
              <iframe
                width="100%"
                height="100%"
                frameBorder="0"
                style={{ border: 0 }}
                src={mapSrc}
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
                title="Ayushman Clinic Location"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
