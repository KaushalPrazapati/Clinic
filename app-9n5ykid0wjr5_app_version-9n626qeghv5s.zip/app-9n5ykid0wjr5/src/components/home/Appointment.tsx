import { useState } from "react";
import { MessageSquare, Calendar, Clock, User, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  phone: z.string().min(10, { message: "Please enter a valid phone number." }),
  time: z.string().min(1, { message: "Please select a preferred time." }),
});

export function Appointment() {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      phone: "",
      time: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const message = `Hello Ayushman Clinic, I would like to book an appointment.\n\nName: ${values.name}\nPhone: ${values.phone}\nPreferred Time: ${values.time}`;
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/919470075755?text=${encodedMessage}`, "_blank");
  }

  return (
    <section id="appointment" className="py-24 bg-background relative">
      <div className="container px-6 mx-auto">
        <div className="max-w-5xl mx-auto bg-primary rounded-[3rem] overflow-hidden shadow-2xl flex flex-col lg:flex-row">
          <div className="lg:w-1/2 p-12 lg:p-16 text-primary-foreground flex flex-col justify-center">
            <h2 className="font-gilda-display text-4xl md:text-5xl font-bold mb-6 leading-tight">
              Ready to Visit <span className="italic text-white/80">Us?</span>
            </h2>
            <p className="text-lg text-white/70 mb-10 leading-relaxed">
              Fill out the form to schedule your visit. We'll confirm your appointment via WhatsApp. For urgent consultations, please call us directly.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold">Operating Hours</div>
                  <div className="text-white/60">Mon - Sat: 10:00 AM - 8:00 PM</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold">Call Directly</div>
                  <div className="text-white/60">094700 75755</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:w-1/2 bg-white p-12 lg:p-16">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground font-bold">Your Name</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <User className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                          <Input 
                            placeholder="Enter your full name" 
                            className="pl-10 h-12 rounded-xl border-border bg-secondary/30 focus:bg-background transition-all" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground font-bold">Phone Number</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Phone className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                          <Input 
                            placeholder="Enter your mobile number" 
                            className="pl-10 h-12 rounded-xl border-border bg-secondary/30 focus:bg-background transition-all" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="time"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground font-bold">Preferred Time</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Clock className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                          <Input 
                            placeholder="e.g. Tomorrow 11:00 AM" 
                            className="pl-10 h-12 rounded-xl border-border bg-secondary/30 focus:bg-background transition-all" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full h-14 rounded-xl text-lg font-bold shadow-lg shadow-primary/10 transition-all hover:scale-[1.02]"
                >
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Request on WhatsApp
                </Button>
                
                <p className="text-center text-xs text-muted-foreground">
                  By clicking, you will be redirected to WhatsApp to complete your booking.
                </p>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
}
