import { Button } from "@/components/ui/button";
import { Phone, MessageSquare, ArrowRight } from "lucide-react";

export function Hero() {
  return (
    <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_436ebbbc-81ad-4940-97b2-f7917a45aeaf.jpg"
          alt="Ayushman Clinic Interior"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-background/40 md:to-transparent" />
      </div>

      <div className="container relative z-10 px-6 mx-auto">
        <div className="max-w-2xl animate-float-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-widest mb-6">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            Open for Consultations
          </div>
          
          <h1 className="font-gilda-display text-5xl md:text-7xl font-bold text-foreground leading-[1.1] mb-6">
            Trusted Healthcare for Your <span className="text-primary italic">Family</span> in Patna
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-10 leading-relaxed max-w-lg">
            OPD • Diagnostics • Medical Store — Everything you need for your health, all under one roof.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              size="lg" 
              className="rounded-full h-14 px-8 text-lg font-bold transition-all hover:translate-y-[-2px] hover:shadow-lg shadow-primary/20"
              onClick={() => window.location.href = "tel:09470075755"}
            >
              <Phone className="mr-2 h-5 w-5" />
              Call Now
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="rounded-full h-14 px-8 text-lg font-bold border-primary text-primary hover:bg-primary/5 transition-all hover:translate-y-[-2px]"
              onClick={() => window.open("https://wa.me/919470075755?text=Hello, I would like to book an appointment at Ayushman Clinic.", "_blank")}
            >
              <MessageSquare className="mr-2 h-5 w-5" />
              WhatsApp Appointment
            </Button>
          </div>

          <div className="mt-12 flex items-center gap-6">
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="w-10 h-10 rounded-full border-2 border-background bg-accent flex items-center justify-center text-[10px] font-bold">
                  {i === 4 ? "+5k" : ""}
                </div>
              ))}
            </div>
            <div className="text-sm">
              <div className="font-bold text-foreground">5000+ Happy Patients</div>
              <div className="text-muted-foreground">Trusted by families in Khajpura & Bailey Road</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative element */}
      <div className="absolute bottom-0 right-0 w-1/3 h-64 bg-primary/5 blur-[120px] rounded-full -mr-32 -mb-32 z-0" />
    </section>
  );
}
