import { Hero } from "@/components/home/Hero";
import { TrustHighlights } from "@/components/home/TrustHighlights";
import { About } from "@/components/home/About";
import { Services } from "@/components/home/Services";
import { Reviews } from "@/components/home/Reviews";
import { Appointment } from "@/components/home/Appointment";
import { LocationContact } from "@/components/home/LocationContact";

export default function Home() {
  return (
    <>
      <Hero />
      <TrustHighlights />
      <About />
      <Services />
      <Reviews />
      <Appointment />
      <LocationContact />
    </>
  );
}
